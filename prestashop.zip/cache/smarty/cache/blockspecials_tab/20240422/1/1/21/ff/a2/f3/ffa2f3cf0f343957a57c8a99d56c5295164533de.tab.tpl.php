<?php /*%%SmartyHeaderCode:20819041126622d121c1eb10-49293418%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ffa2f3cf0f343957a57c8a99d56c5295164533de' => 
    array (
      0 => '/var/www/html/modules/blockspecials/views/templates/hook/tab.tpl',
      1 => 1460113478,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20819041126622d121c1eb10-49293418',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_6625e1906904e4_54625411',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_6625e1906904e4_54625411')) {function content_6625e1906904e4_54625411($_smarty_tpl) {?><li><a data-toggle="tab" href="#blockspecials" class="blockspecials">Specials</a></li>
<?php }} ?>
