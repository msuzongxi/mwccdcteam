<?php /*%%SmartyHeaderCode:13642444016622d1222510a0-85545083%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '44a3ca6f70fb7cf18ad9ccaabb7c9b7695475dd2' => 
    array (
      0 => '/var/www/html/themes/default-bootstrap/modules/blockcontactinfos/blockcontactinfos.tpl',
      1 => 1460113476,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13642444016622d1222510a0-85545083',
  'variables' => 
  array (
    'blockcontactinfos_company' => 0,
    'blockcontactinfos_address' => 0,
    'blockcontactinfos_phone' => 0,
    'blockcontactinfos_email' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_6622d1222737a5_45028829',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_6622d1222737a5_45028829')) {function content_6622d1222737a5_45028829($_smarty_tpl) {?>
<!-- MODULE Block contact infos -->
<section id="block_contact_infos" class="footer-block col-xs-12 col-sm-4">
	<div>
        <h4>Store Information</h4>
        <ul class="toggle-footer">
                        	<li>
            		<i class="icon-map-marker"></i>test            	</li>
                                                	<li>
            		<i class="icon-envelope-alt"></i>Email: 
            		<span><a href="&#109;&#97;&#105;&#108;&#116;&#111;&#58;%7a%6f%6e%67%78%69%6c%69%75@%6d%69%73%73%6f%75%72%69%73%74%61%74%65.%65%64%75" >&#x7a;&#x6f;&#x6e;&#x67;&#x78;&#x69;&#x6c;&#x69;&#x75;&#x40;&#x6d;&#x69;&#x73;&#x73;&#x6f;&#x75;&#x72;&#x69;&#x73;&#x74;&#x61;&#x74;&#x65;&#x2e;&#x65;&#x64;&#x75;</a></span>
            	</li>
                    </ul>
    </div>
</section>
<!-- /MODULE Block contact infos -->
<?php }} ?>
