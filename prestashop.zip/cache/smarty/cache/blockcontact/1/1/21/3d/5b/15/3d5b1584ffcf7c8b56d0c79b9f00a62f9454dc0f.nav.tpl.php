<?php /*%%SmartyHeaderCode:18479607366622d1223aabd4-99392567%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3d5b1584ffcf7c8b56d0c79b9f00a62f9454dc0f' => 
    array (
      0 => '/var/www/html/themes/default-bootstrap/modules/blockcontact/nav.tpl',
      1 => 1460113476,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18479607366622d1223aabd4-99392567',
  'variables' => 
  array (
    'is_logged' => 0,
    'link' => 0,
    'telnumber' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_6622d1223c39c7_07858971',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_6622d1223c39c7_07858971')) {function content_6622d1223c39c7_07858971($_smarty_tpl) {?><div id="contact-link" >
	<a href="http://20.80.239.206/index.php?controller=contact" title="Contact us">Contact us</a>
</div>
<?php }} ?>
