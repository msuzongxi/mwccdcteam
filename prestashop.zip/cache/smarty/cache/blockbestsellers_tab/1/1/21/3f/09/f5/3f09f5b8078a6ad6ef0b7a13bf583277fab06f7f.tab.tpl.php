<?php /*%%SmartyHeaderCode:20018939616622d121bc7a41-82267334%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3f09f5b8078a6ad6ef0b7a13bf583277fab06f7f' => 
    array (
      0 => '/var/www/html/modules/blockbestsellers/views/templates/hook/tab.tpl',
      1 => 1460113476,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20018939616622d121bc7a41-82267334',
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_6622d121bcbe61_16904537',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_6622d121bcbe61_16904537')) {function content_6622d121bcbe61_16904537($_smarty_tpl) {?><li><a data-toggle="tab" href="#blockbestsellers" class="blockbestsellers">Best Sellers</a></li><?php }} ?>
