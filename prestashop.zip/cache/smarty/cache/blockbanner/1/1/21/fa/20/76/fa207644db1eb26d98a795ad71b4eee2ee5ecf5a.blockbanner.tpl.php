<?php /*%%SmartyHeaderCode:10638694826622d12236c3f7-70946171%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fa207644db1eb26d98a795ad71b4eee2ee5ecf5a' => 
    array (
      0 => '/var/www/html/modules/blockbanner/blockbanner.tpl',
      1 => 1460113476,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10638694826622d12236c3f7-70946171',
  'variables' => 
  array (
    'banner_link' => 0,
    'force_ssl' => 0,
    'base_dir_ssl' => 0,
    'base_dir' => 0,
    'banner_desc' => 0,
    'banner_img' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_6622d12238d096_12537404',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_6622d12238d096_12537404')) {function content_6622d12238d096_12537404($_smarty_tpl) {?><a href="http://20.80.239.206/" title="">
	<img class="img-responsive" src="http://20.80.239.206/modules/blockbanner/img/sale70.png" alt="" title="" width="1170" height="65" />
</a>
<?php }} ?>
