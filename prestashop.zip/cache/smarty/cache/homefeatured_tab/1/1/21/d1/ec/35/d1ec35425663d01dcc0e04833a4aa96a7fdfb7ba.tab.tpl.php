<?php /*%%SmartyHeaderCode:7278001716622d121c45957-65129039%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd1ec35425663d01dcc0e04833a4aa96a7fdfb7ba' => 
    array (
      0 => '/var/www/html/modules/homefeatured/views/templates/hook/tab.tpl',
      1 => 1460113478,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7278001716622d121c45957-65129039',
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_6622d121c49870_79126949',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_6622d121c49870_79126949')) {function content_6622d121c49870_79126949($_smarty_tpl) {?><li><a data-toggle="tab" href="#homefeatured" class="homefeatured">Popular</a></li><?php }} ?>
