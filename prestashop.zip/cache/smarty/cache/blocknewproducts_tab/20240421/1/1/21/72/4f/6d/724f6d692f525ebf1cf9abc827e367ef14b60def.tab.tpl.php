<?php /*%%SmartyHeaderCode:3067302876622d121bf9b28-07025402%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '724f6d692f525ebf1cf9abc827e367ef14b60def' => 
    array (
      0 => '/var/www/html/modules/blocknewproducts/views/templates/hook/tab.tpl',
      1 => 1460113476,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3067302876622d121bf9b28-07025402',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_66249406728ca3_89020738',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_66249406728ca3_89020738')) {function content_66249406728ca3_89020738($_smarty_tpl) {?><li><a data-toggle="tab" href="#blocknewproducts" class="blocknewproducts">New arrivals</a></li>
<?php }} ?>
