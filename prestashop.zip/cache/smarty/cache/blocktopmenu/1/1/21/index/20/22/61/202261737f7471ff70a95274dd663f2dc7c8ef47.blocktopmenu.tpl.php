<?php /*%%SmartyHeaderCode:7520858556622d121a349f9-48321604%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '202261737f7471ff70a95274dd663f2dc7c8ef47' => 
    array (
      0 => '/var/www/html/themes/default-bootstrap/modules/blocktopmenu/blocktopmenu.tpl',
      1 => 1460113476,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7520858556622d121a349f9-48321604',
  'variables' => 
  array (
    'MENU' => 0,
    'MENU_SEARCH' => 0,
    'link' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_6622d121a49ec5_45683940',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_6622d121a49ec5_45683940')) {function content_6622d121a49ec5_45683940($_smarty_tpl) {?>	<!-- Menu -->
	<div id="block_top_menu" class="sf-contener clearfix col-lg-12">
		<div class="cat-title">Menu</div>
		<ul class="sf-menu clearfix menu-content">
			<li><a href="http://20.80.239.206/index.php?id_category=3&amp;controller=category" title="Women">Women</a><ul><li><a href="http://20.80.239.206/index.php?id_category=4&amp;controller=category" title="Tops">Tops</a><ul><li><a href="http://20.80.239.206/index.php?id_category=5&amp;controller=category" title="T-shirts">T-shirts</a></li><li><a href="http://20.80.239.206/index.php?id_category=7&amp;controller=category" title="Blouses">Blouses</a></li></ul></li><li><a href="http://20.80.239.206/index.php?id_category=8&amp;controller=category" title="Dresses">Dresses</a><ul><li><a href="http://20.80.239.206/index.php?id_category=9&amp;controller=category" title="Casual Dresses">Casual Dresses</a></li><li><a href="http://20.80.239.206/index.php?id_category=10&amp;controller=category" title="Evening Dresses">Evening Dresses</a></li><li><a href="http://20.80.239.206/index.php?id_category=11&amp;controller=category" title="Summer Dresses">Summer Dresses</a></li></ul></li><li class="category-thumbnail"><div><img src="http://20.80.239.206/img/c/3-0_thumb.jpg" alt="Women" title="Women" class="imgm" /></div><div><img src="http://20.80.239.206/img/c/3-1_thumb.jpg" alt="Women" title="Women" class="imgm" /></div></li></ul></li>
							<li class="sf-search noBack" style="float:right">
					<form id="searchbox" action="http://20.80.239.206/index.php?controller=search" method="get">
						<p>
							<input type="hidden" name="controller" value="search" />
							<input type="hidden" value="position" name="orderby"/>
							<input type="hidden" value="desc" name="orderway"/>
							<input type="text" name="search_query" value="" />
						</p>
					</form>
				</li>
					</ul>
	</div>
	<!--/ Menu -->
<?php }} ?>
