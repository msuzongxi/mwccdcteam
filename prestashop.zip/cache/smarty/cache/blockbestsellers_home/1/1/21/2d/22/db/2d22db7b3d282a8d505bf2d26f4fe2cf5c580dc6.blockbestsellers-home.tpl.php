<?php /*%%SmartyHeaderCode:7883936296622d121c6b4b0-58171339%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2d22db7b3d282a8d505bf2d26f4fe2cf5c580dc6' => 
    array (
      0 => '/var/www/html/modules/blockbestsellers/views/templates/hook/blockbestsellers-home.tpl',
      1 => 1460113476,
      2 => 'file',
    ),
    '2e293430358618132e55da3280d956082e63020b' => 
    array (
      0 => '/var/www/html/themes/default-bootstrap/product-list.tpl',
      1 => 1460113476,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '7883936296622d121c6b4b0-58171339',
  'variables' => 
  array (
    'best_sellers' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_6622d121f12373_00617161',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_6622d121f12373_00617161')) {function content_6622d121f12373_00617161($_smarty_tpl) {?>		
									
		
	
	<!-- Products list -->
	<ul id="blockbestsellers" class="product_list grid row blockbestsellers tab-pane">
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 first-in-line first-item-of-tablet-line first-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://20.80.239.206/index.php?id_product=2&amp;controller=product" title="Blouse" itemprop="url">
							<img class="replace-2x img-responsive" src="http://20.80.239.206/img/p/7/7-home_default.jpg" alt="Blouse" title="Blouse"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://20.80.239.206/index.php?id_product=2&amp;controller=product" rel="http://20.80.239.206/index.php?id_product=2&amp;controller=product">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://20.80.239.206/index.php?id_product=2&amp;controller=product" rel="http://20.80.239.206/index.php?id_product=2&amp;controller=product">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										$27.00									</span>
									<meta itemprop="priceCurrency" content="USD" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In Stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://20.80.239.206/index.php?id_product=2&amp;controller=product">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://20.80.239.206/index.php?id_product=2&amp;controller=product" title="Blouse" itemprop="url" >
							Blouse
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Short-sleeved blouse with feminine draped sleeve detail.
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								$27.00							</span>
														
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="http://20.80.239.206/index.php?controller=cart&amp;add=1&amp;id_product=2&amp;ipa=7&amp;token=8830b0b0422f54dddab24e09cd91c78e" rel="nofollow" title="Add to cart" data-id-product-attribute="7" data-id-product="2" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://20.80.239.206/index.php?id_product=2&amp;controller=product" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class=" label-success">
										In Stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://20.80.239.206/index.php?id_product=3&amp;controller=product" title="Printed Dress" itemprop="url">
							<img class="replace-2x img-responsive" src="http://20.80.239.206/img/p/8/8-home_default.jpg" alt="Printed Dress" title="Printed Dress"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://20.80.239.206/index.php?id_product=3&amp;controller=product" rel="http://20.80.239.206/index.php?id_product=3&amp;controller=product">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://20.80.239.206/index.php?id_product=3&amp;controller=product" rel="http://20.80.239.206/index.php?id_product=3&amp;controller=product">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										$26.00									</span>
									<meta itemprop="priceCurrency" content="USD" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In Stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://20.80.239.206/index.php?id_product=3&amp;controller=product">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://20.80.239.206/index.php?id_product=3&amp;controller=product" title="Printed Dress" itemprop="url" >
							Printed Dress
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						100% cotton double printed dress. Black and white striped top and orange high waisted skater skirt bottom.
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								$26.00							</span>
														
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="http://20.80.239.206/index.php?controller=cart&amp;add=1&amp;id_product=3&amp;ipa=13&amp;token=8830b0b0422f54dddab24e09cd91c78e" rel="nofollow" title="Add to cart" data-id-product-attribute="13" data-id-product="3" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://20.80.239.206/index.php?id_product=3&amp;controller=product" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class=" label-success">
										In Stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-item-of-tablet-line first-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://20.80.239.206/index.php?id_product=1&amp;controller=product" title="Faded Short Sleeves T-shirt" itemprop="url">
							<img class="replace-2x img-responsive" src="http://20.80.239.206/img/p/1/1-home_default.jpg" alt="Faded Short Sleeves T-shirt" title="Faded Short Sleeves T-shirt"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://20.80.239.206/index.php?id_product=1&amp;controller=product" rel="http://20.80.239.206/index.php?id_product=1&amp;controller=product">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://20.80.239.206/index.php?id_product=1&amp;controller=product" rel="http://20.80.239.206/index.php?id_product=1&amp;controller=product">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										$16.51									</span>
									<meta itemprop="priceCurrency" content="USD" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In Stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://20.80.239.206/index.php?id_product=1&amp;controller=product">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://20.80.239.206/index.php?id_product=1&amp;controller=product" title="Faded Short Sleeves T-shirt" itemprop="url" >
							Faded Short Sleeves T-shirt
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Faded short sleeves t-shirt with high neckline. Soft and stretchy material for a comfortable fit. Accessorize with a straw hat and you're ready for summer!
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								$16.51							</span>
														
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="http://20.80.239.206/index.php?controller=cart&amp;add=1&amp;id_product=1&amp;ipa=1&amp;token=8830b0b0422f54dddab24e09cd91c78e" rel="nofollow" title="Add to cart" data-id-product-attribute="1" data-id-product="1" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://20.80.239.206/index.php?id_product=1&amp;controller=product" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class=" label-success">
										In Stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-in-line first-item-of-tablet-line last-item-of-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://20.80.239.206/index.php?id_product=7&amp;controller=product" title="Printed Chiffon Dress" itemprop="url">
							<img class="replace-2x img-responsive" src="http://20.80.239.206/img/p/2/0/20-home_default.jpg" alt="Printed Chiffon Dress" title="Printed Chiffon Dress"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://20.80.239.206/index.php?id_product=7&amp;controller=product" rel="http://20.80.239.206/index.php?id_product=7&amp;controller=product">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://20.80.239.206/index.php?id_product=7&amp;controller=product" rel="http://20.80.239.206/index.php?id_product=7&amp;controller=product">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										$16.40									</span>
									<meta itemprop="priceCurrency" content="USD" />
																			
										<span class="old-price product-price">
											$20.50
										</span>
																					<span class="price-percent-reduction">-20%</span>
																																						<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In Stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://20.80.239.206/index.php?id_product=7&amp;controller=product">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://20.80.239.206/index.php?id_product=7&amp;controller=product" title="Printed Chiffon Dress" itemprop="url" >
							Printed Chiffon Dress
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Printed chiffon knee length dress with tank straps. Deep v-neckline.
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								$16.40							</span>
															
								<span class="old-price product-price">
									$20.50
								</span>
								
																	<span class="price-percent-reduction">-20%</span>
																						
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="http://20.80.239.206/index.php?controller=cart&amp;add=1&amp;id_product=7&amp;ipa=34&amp;token=8830b0b0422f54dddab24e09cd91c78e" rel="nofollow" title="Add to cart" data-id-product-attribute="34" data-id-product="7" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://20.80.239.206/index.php?id_product=7&amp;controller=product" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																																	<span class="discount">Reduced price!</span>
												</div>
																		<span class="availability">
																	<span class=" label-success">
										In Stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 first-in-line last-line first-item-of-mobile-line last-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://20.80.239.206/index.php?id_product=6&amp;controller=product" title="Printed Summer Dress" itemprop="url">
							<img class="replace-2x img-responsive" src="http://20.80.239.206/img/p/1/6/16-home_default.jpg" alt="Printed Summer Dress" title="Printed Summer Dress"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://20.80.239.206/index.php?id_product=6&amp;controller=product" rel="http://20.80.239.206/index.php?id_product=6&amp;controller=product">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://20.80.239.206/index.php?id_product=6&amp;controller=product" rel="http://20.80.239.206/index.php?id_product=6&amp;controller=product">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										$30.50									</span>
									<meta itemprop="priceCurrency" content="USD" />
																												<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In Stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://20.80.239.206/index.php?id_product=6&amp;controller=product">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://20.80.239.206/index.php?id_product=6&amp;controller=product" title="Printed Summer Dress" itemprop="url" >
							Printed Summer Dress
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Sleeveless knee-length chiffon dress. V-neckline with elastic under the bust lining.
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								$30.50							</span>
														
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="http://20.80.239.206/index.php?controller=cart&amp;add=1&amp;id_product=6&amp;ipa=31&amp;token=8830b0b0422f54dddab24e09cd91c78e" rel="nofollow" title="Add to cart" data-id-product-attribute="31" data-id-product="6" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://20.80.239.206/index.php?id_product=6&amp;controller=product" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																														</div>
																		<span class="availability">
																	<span class=" label-success">
										In Stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
			
		
		
								<li class="ajax_block_product col-xs-12 col-sm-4 col-md-3 last-line last-item-of-tablet-line last-item-of-mobile-line last-mobile-line">
			<div class="product-container" itemscope itemtype="https://schema.org/Product">
				<div class="left-block">
					<div class="product-image-container">
						<a class="product_img_link" href="http://20.80.239.206/index.php?id_product=5&amp;controller=product" title="Printed Summer Dress" itemprop="url">
							<img class="replace-2x img-responsive" src="http://20.80.239.206/img/p/1/2/12-home_default.jpg" alt="Printed Summer Dress" title="Printed Summer Dress"  width="250" height="250" itemprop="image" />
						</a>
													<div class="quick-view-wrapper-mobile">
							<a class="quick-view-mobile" href="http://20.80.239.206/index.php?id_product=5&amp;controller=product" rel="http://20.80.239.206/index.php?id_product=5&amp;controller=product">
								<i class="icon-eye-open"></i>
							</a>
						</div>
						<a class="quick-view" href="http://20.80.239.206/index.php?id_product=5&amp;controller=product" rel="http://20.80.239.206/index.php?id_product=5&amp;controller=product">
							<span>Quick view</span>
						</a>
																			<div class="content_price" itemprop="offers" itemscope itemtype="https://schema.org/Offer">
																	<span itemprop="price" class="price product-price">
										
										$28.98									</span>
									<meta itemprop="priceCurrency" content="USD" />
																			
										<span class="old-price product-price">
											$30.51
										</span>
																					<span class="price-percent-reduction">-5%</span>
																																						<span class="unvisible">
																								<link itemprop="availability" href="https://schema.org/InStock" />In Stock																					</span>
																		
									
															</div>
																			<a class="new-box" href="http://20.80.239.206/index.php?id_product=5&amp;controller=product">
								<span class="new-label">New</span>
							</a>
																	</div>
										
				</div>
				<div class="right-block">
					<h5 itemprop="name">
												<a class="product-name" href="http://20.80.239.206/index.php?id_product=5&amp;controller=product" title="Printed Summer Dress" itemprop="url" >
							Printed Summer Dress
						</a>
					</h5>
															<p class="product-desc" itemprop="description">
						Long printed dress with thin adjustable straps. V-neckline and wiring under the bust with ruffles at the bottom of the dress.
					</p>
										<div class="content_price">
													
							<span class="price product-price">
								$28.98							</span>
															
								<span class="old-price product-price">
									$30.51
								</span>
								
																	<span class="price-percent-reduction">-5%</span>
																						
							
							
											</div>
										<div class="button-container">
																													<a class="button ajax_add_to_cart_button btn btn-default" href="http://20.80.239.206/index.php?controller=cart&amp;add=1&amp;id_product=5&amp;ipa=19&amp;token=8830b0b0422f54dddab24e09cd91c78e" rel="nofollow" title="Add to cart" data-id-product-attribute="19" data-id-product="5" data-minimal_quantity="1">
									<span>Add to cart</span>
								</a>
																			<a class="button lnk_view btn btn-default" href="http://20.80.239.206/index.php?id_product=5&amp;controller=product" title="View">
							<span>More</span>
						</a>
					</div>
										<div class="product-flags">
																																	<span class="discount">Reduced price!</span>
												</div>
																		<span class="availability">
																	<span class=" label-success">
										In Stock									</span>
															</span>
															</div>
							</div><!-- .product-container> -->
		</li>
		</ul>





<?php }} ?>
