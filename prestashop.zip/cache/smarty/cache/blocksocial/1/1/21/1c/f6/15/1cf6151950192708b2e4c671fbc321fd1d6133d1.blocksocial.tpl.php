<?php /*%%SmartyHeaderCode:3555427256622d1220aaa00-34791421%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1cf6151950192708b2e4c671fbc321fd1d6133d1' => 
    array (
      0 => '/var/www/html/themes/default-bootstrap/modules/blocksocial/blocksocial.tpl',
      1 => 1460113476,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3555427256622d1220aaa00-34791421',
  'variables' => 
  array (
    'facebook_url' => 0,
    'twitter_url' => 0,
    'rss_url' => 0,
    'youtube_url' => 0,
    'google_plus_url' => 0,
    'pinterest_url' => 0,
    'vimeo_url' => 0,
    'instagram_url' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_6622d1220f91c1_70580993',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_6622d1220f91c1_70580993')) {function content_6622d1220f91c1_70580993($_smarty_tpl) {?><section id="social_block" class="pull-right">
	<ul>
						                                        	</ul>
    <h4>Follow us</h4>
</section>
<div class="clearfix"></div>
<?php }} ?>
