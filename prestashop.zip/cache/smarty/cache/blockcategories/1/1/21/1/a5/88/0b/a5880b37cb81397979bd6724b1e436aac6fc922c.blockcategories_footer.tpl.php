<?php /*%%SmartyHeaderCode:15744001036622d1221258f3-98617251%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a5880b37cb81397979bd6724b1e436aac6fc922c' => 
    array (
      0 => '/var/www/html/themes/default-bootstrap/modules/blockcategories/blockcategories_footer.tpl',
      1 => 1460113476,
      2 => 'file',
    ),
    '5c53737510b61f5e57aa4fb383106c38f28d329a' => 
    array (
      0 => '/var/www/html/themes/default-bootstrap/modules/blockcategories/category-tree-branch.tpl',
      1 => 1460113476,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15744001036622d1221258f3-98617251',
  'variables' => 
  array (
    'isDhtml' => 0,
    'blockCategTree' => 0,
    'child' => 0,
    'numberColumn' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_6622d122173f03_54029755',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_6622d122173f03_54029755')) {function content_6622d122173f03_54029755($_smarty_tpl) {?>
<!-- Block categories module -->
<section class="blockcategories_footer footer-block col-xs-12 col-sm-2">
	<h4>Categories</h4>
	<div class="category_footer toggle-footer">
		<div class="list">
			<ul class="tree dhtml">
												
<li class="last">
	<a 
	href="http://20.80.239.206/index.php?id_category=3&amp;controller=category" title="You will find here all woman fashion collections.  
 This category includes all the basics of your wardrobe and much more: 
 shoes, accessories, printed t-shirts, feminine dresses, women&#039;s jeans!">
		Women
	</a>
			<ul>
												
<li >
	<a 
	href="http://20.80.239.206/index.php?id_category=4&amp;controller=category" title="Choose from t-shirts, tops, blouses, short sleeves, long sleeves, tank tops, 3/4 sleeves and more. 
 Find the cut that suits you the best!">
		Tops
	</a>
			<ul>
												
<li >
	<a 
	href="http://20.80.239.206/index.php?id_category=5&amp;controller=category" title="The must have of your wardrobe, take a look at our different colors, 
 shapes and style of our collection!">
		T-shirts
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://20.80.239.206/index.php?id_category=7&amp;controller=category" title="Match your favorites blouses with the right accessories for the perfect look.">
		Blouses
	</a>
	</li>

									</ul>
	</li>

																
<li class="last">
	<a 
	href="http://20.80.239.206/index.php?id_category=8&amp;controller=category" title="Find your favorites dresses from our wide choice of evening, casual or summer dresses! 
 We offer dresses for every day, every style and every occasion.">
		Dresses
	</a>
			<ul>
												
<li >
	<a 
	href="http://20.80.239.206/index.php?id_category=9&amp;controller=category" title="You are looking for a dress for every day? Take a look at 
 our selection of dresses to find one that suits you.">
		Casual Dresses
	</a>
	</li>

																
<li >
	<a 
	href="http://20.80.239.206/index.php?id_category=10&amp;controller=category" title="Browse our different dresses to choose the perfect dress for an unforgettable evening!">
		Evening Dresses
	</a>
	</li>

																
<li class="last">
	<a 
	href="http://20.80.239.206/index.php?id_category=11&amp;controller=category" title="Short dress, long dress, silk dress, printed dress, you will find the perfect dress for summer.">
		Summer Dresses
	</a>
	</li>

									</ul>
	</li>

									</ul>
	</li>

							
										</ul>
		</div>
	</div> <!-- .category_footer -->
</section>
<!-- /Block categories module -->
<?php }} ?>
