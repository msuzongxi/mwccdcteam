<?php /*%%SmartyHeaderCode:18392945246622d1223ea2c4-08781298%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b79917e19c39a5c2f6896b068d19cda5bdc51987' => 
    array (
      0 => '/var/www/html/themes/default-bootstrap/modules/homeslider/homeslider.tpl',
      1 => 1460113476,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18392945246622d1223ea2c4-08781298',
  'variables' => 
  array (
    'page_name' => 0,
    'homeslider_slides' => 0,
    'slide' => 0,
    'link' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_6622d12242e9c8_20814035',
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_6622d12242e9c8_20814035')) {function content_6622d12242e9c8_20814035($_smarty_tpl) {?><!-- Module HomeSlider -->
    		<div id="homepage-slider">
						<ul id="homeslider" style="max-height:448px;">
															<li class="homeslider-container">
							<a href="http://www.prestashop.com/?utm_source=back-office&amp;utm_medium=v16_homeslider&amp;utm_campaign=back-office-EN&amp;utm_content=download" title="sample-1">
								<img src="http://20.80.239.206/modules/homeslider/images/sample-1.jpg" width="779" height="448" alt="sample-1" />
							</a>
															<div class="homeslider-description"><h2>EXCEPTEUR<br />OCCAECAT</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin tristique in tortor et dignissim. Quisque non tempor leo. Maecenas egestas sem elit</p>
				<p><button class="btn btn-default" type="button">Shop now !</button></p></div>
													</li>
																				<li class="homeslider-container">
							<a href="http://www.prestashop.com/?utm_source=back-office&amp;utm_medium=v16_homeslider&amp;utm_campaign=back-office-EN&amp;utm_content=download" title="sample-2">
								<img src="http://20.80.239.206/modules/homeslider/images/sample-2.jpg" width="779" height="448" alt="sample-2" />
							</a>
															<div class="homeslider-description"><h2>EXCEPTEUR<br />OCCAECAT</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin tristique in tortor et dignissim. Quisque non tempor leo. Maecenas egestas sem elit</p>
				<p><button class="btn btn-default" type="button">Shop now !</button></p></div>
													</li>
																				<li class="homeslider-container">
							<a href="http://www.prestashop.com/?utm_source=back-office&amp;utm_medium=v16_homeslider&amp;utm_campaign=back-office-EN&amp;utm_content=download" title="sample-3">
								<img src="http://20.80.239.206/modules/homeslider/images/sample-3.jpg" width="779" height="448" alt="sample-3" />
							</a>
															<div class="homeslider-description"><h2>EXCEPTEUR<br />OCCAECAT</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin tristique in tortor et dignissim. Quisque non tempor leo. Maecenas egestas sem elit</p>
				<p><button class="btn btn-default" type="button">Shop now !</button></p></div>
													</li>
												</ul>
		</div>
	<!-- /Module HomeSlider -->
<?php }} ?>
